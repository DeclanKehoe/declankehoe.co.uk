library('igraph')
library('GGally')
library('RColorBrewer')
library('statnet')
library('intergraph')
library('network')

#### Setup ####
# Read in the edge lists of the three films
edgL4 <- read.csv('SW4_links.csv')
edgL5 <- read.csv('SW5_links.csv')
edgL6 <- read.csv('SW6_links.csv')

# Turn them into networks
sw4Net <- as.network(edgL4, matrix.type = 'edgelist',  
                    directed = FALSE, vertex.names = NULL)
sw5Net <- as.network(edgL5, matrix.type = 'edgelist', 
                     directed = FALSE, vertex.names = NULL)
sw6Net <- as.network(edgL6, matrix.type = 'edgelist', 
                     directed = FALSE, vertex.names = NULL)

# Read in the character attributes
charAtr4 <- as.matrix(read.table('SW4.txt', header = TRUE))
charAtr5 <- as.matrix(read.table('SW5.txt', header = TRUE))
charAtr6 <- as.matrix(read.table('SW6.txt', header = TRUE))

# Attach the attributes to the networks
sw4Net %v% 'Name' <- charAtr4[,2]
sw5Net %v% 'Name' <- charAtr5[,2]
sw6Net %v% 'Name' <- charAtr6[,2]

sw4Net %v% 'Faction' <- charAtr4[,3]
sw5Net %v% 'Faction' <- charAtr5[,3]
sw6Net %v% 'Faction' <- charAtr6[,3]

sw4Net %v% 'FactionId' <- as.numeric(charAtr4[,4])
sw5Net %v% 'FactionId' <- as.numeric(charAtr5[,4])
sw6Net %v% 'FactionId' <- as.numeric(charAtr6[,4])

sw4Net %v% 'Force' <- charAtr4[,5]
sw5Net %v% 'Force' <- charAtr5[,5]
sw6Net %v% 'Force' <- charAtr6[,5]

sw4Net %v% 'ForceId' <- as.numeric(charAtr4[,6])
sw5Net %v% 'ForceId' <- as.numeric(charAtr5[,6])
sw6Net %v% 'ForceId' <- as.numeric(charAtr6[,6])

sw4Net %v% 'ForceCol' <- charAtr4[,7]
sw5Net %v% 'ForceCol' <- charAtr5[,7]
sw6Net %v% 'ForceCol' <- charAtr6[,7]

# Make an igraph and matrix of all this for potential later use
sw4Ig <- asIgraph(sw4Net)
sw5Ig <- asIgraph(sw5Net)
sw6Ig <- asIgraph(sw6Net)

sw4Mat <- as.matrix(sw4Net)
sw5Mat <- as.matrix(sw5Net)
sw6Mat <- as.matrix(sw6Net)
#### Plotting ####
# Summarise and plot the networks with force and faction colours
summary(sw4Net)
ggnet2(sw4Net, mode = 'circle', color.palette = 'Pastel1', edge.color = 'grey',
       node.color = 'Faction', node.size = 20, legend.position = 'none',
       label = 'Name', label.color = 'ForceCol', label.size = 7)

summary(sw5Net)
ggnet2(sw5Net, mode = 'circle', color.palette = 'Pastel1', edge.color = 'grey',
       node.color = 'Faction', node.size = 20, legend.position = 'none',
       label = 'Name', label.color = 'ForceCol', label.size = 7)

summary(sw6Net)
ggnet2(sw6Net, mode = 'circle', color.palette = 'Pastel1', edge.color = 'grey',
       node.color = 'Faction', node.size = 20, legend.position = 'none',
       label = 'Name', label.color = 'ForceCol', label.size = 7)

#### Hypothesis Test ####
# ERGMs Let's Go, add diff=TRUE to nodematch for differential homophily
sw4ERGM <- ergm(sw4Net ~ edges 
                + nodematch('Faction')
                + nodefactor('Force')
                + gwesp(decay = 0.5, fixed = TRUE))

sw5ERGM <- ergm(sw5Net ~ edges 
                + nodematch('Faction')
                + nodefactor('Force')
                + gwesp(decay = 0.5, fixed = TRUE))

sw6ERGM <- ergm(sw6Net ~ edges 
                + nodematch('FactionId')
                + nodefactor('Force')
                + gwesp(decay = 0.5, fixed = TRUE))

#### Goodness of fit ####
# Do GoF for each and then plot them, simples
mcmc.diagnostics(sw4ERGM)
gof4 <- gof(sw4ERGM ~ degree + distance)
par(mfrow = c(2, 2))
plot(gof4, main = 'Episode 4 ERGM Goodness of Fit')

mcmc.diagnostics(sw5ERGM)
gof5 <- gof(sw5ERGM ~ degree + distance)
par(mfrow = c(2,2))
plot(gof5, main = 'Episode 5 ERGM Goodness of Fit')

mcmc.diagnostics(sw6ERGM)
gof6 <- gof(sw6ERGM ~ degree + distance)
par(mfrow = c(2,2))
plot(gof6, main = 'Episode 6 ERGM Goodness of Fit')

#### Get the results, we done ####
summary(sw4ERGM)

summary(sw5ERGM)

summary(sw6ERGM)

